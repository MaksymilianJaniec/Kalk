import React from 'react';
import './Obliczenia.css';

class Kalkulator extends React.Component {
    constructor(props) {
      super(props);
      this.state = { 
        a: '', 
        b: '',
        wynik: '' 
      };
      this.handleChangeA = this.handleChangeA.bind(this);
      this.handleChangeB = this.handleChangeB.bind(this);
      this.handleCalculate = this.handleCalculate.bind(this);
    }
   
    render() {
      return (
        <div className="obliczenia">
          <form>
            Liczba1:<input type="text" onChange={this.handleChangeA} value={this.state.a}/> <br /><br />
            Liczba2:<input type="text" onChange={this.handleChangeB} value={this.state.b}/> <br /><br />
            <button type="button" onClick={this.handleCalculate}>+</button>
            <button type="button" onClick={this.handleCalculate}>-</button>
            <button type="button" onClick={this.handleCalculate}>x</button>
            <button type="button" onClick={this.handleCalculate}>/</button>
            <button type="button" onClick={this.handleCalculate}>**</button><br /><br />
            Wynik:<input type="text" value={this.state.wynik} /> 
            
          </form>
        </div>
      );
    }
   
    handleChangeA(e) {
      this.setState({ a: e.target.value });
    }
   
    handleChangeB(e) {
      this.setState({ b: e.target.value });
    }
   
    handleCalculate(e) 
    {
      e.preventDefault();
   
      switch(e.target.innerText) 
      {
          case '+':
            var wynik = parseFloat(this.state.a) + parseFloat(this.state.b);         
          break;
          case '-':
            var wynik = parseFloat(this.state.a) - parseFloat(this.state.b);         
          break;  
          case 'x':
            var wynik = parseFloat(this.state.a) * parseFloat(this.state.b);         
          break;  
          case '/':
            var wynik = parseFloat(this.state.a) / parseFloat(this.state.b);         
          break;    
          case '**':
            var wynik = parseFloat(this.state.a) * parseFloat(this.state.a);         
          break;    
      }
   
      this.setState({ wynik: wynik });
    }
   
  }
   
export default Kalkulator;
